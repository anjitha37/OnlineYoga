

import React, { useEffect, useRef } from "react";
import { Container, Navbar, Nav, Carousel } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import gsap from "gsap";
import { HomeNavbarAnimation } from "../utils/gsapAnimation";
import ScrollTrigger from "gsap/ScrollTrigger";
import img1 from "../assets/image.png";
import img2 from "../assets/img1.jpeg";
import img3 from "../assets/img2.jpeg";
import "../index.css";

gsap.registerPlugin(ScrollTrigger);

const Homepage = () => {
  const navbarRef = useRef(null);

  useEffect(() => {
    HomeNavbarAnimation(navbarRef);

    gsap.utils.toArray(".hero-slide").forEach((slide) => {
      gsap.fromTo(
        slide.querySelector(".animate-hero-title"),
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 1,
          ease: "power3.out",
          scrollTrigger: {
            trigger: slide,
            start: "top center",
          },
        }
      );

      gsap.fromTo(
        slide.querySelector(".animate-hero-sub"),
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 1,
          delay: 0.3,
          ease: "power3.out",
          scrollTrigger: {
            trigger: slide,
            start: "top center",
          },
        }
      );
    });
  }, []);

  const popularSessions = [
    { img: img1, title: "Morning Flow" },
    { img: img2, title: "Power Yoga" },
    { img: img3, title: "Kids Session" },
  ];

  return (
    <div className="homepage-container">
      {/* Navbar */}
      <Navbar
        ref={navbarRef}
        className="custom-navbar"
        variant="dark"
        expand="lg"
        fixed="top"
      >
        <Container>
          <Navbar.Brand href="#home" className="project-title">YogaStream</Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="ms-auto">
              <Nav.Link href="#home" className="nav-link-custom">
                Home
              </Nav.Link>
              <Nav.Link href="#about" className="nav-link-custom">
                About Us
              </Nav.Link>
              <Nav.Link href="/register" className="nav-link-custom">
                Register
              </Nav.Link>
              <Nav.Link href="/login" className="nav-link-custom">
                Sign In
              </Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>

      {/* Hero Section with Carousel */}
      <main className="hero-carousel-section" id="home">
        <Carousel fade interval={4000} pause="hover" indicators controls>
          {popularSessions.map((session, index) => (
            <Carousel.Item key={index} className="hero-slide">
              <img
                className="d-block w-100 carousel-hero-image"
                src={session.img}
                alt={session.title}
              />
              <Carousel.Caption>
                <div className="hero-overlay">
                  <h1 className="hero-heading animate-hero-title">
                    Embrace Wellness with Online Yoga
                  </h1>
                  <p className="hero-subtext animate-hero-sub">
                    {session.title} – Live & On-Demand Yoga with Certified Instructors.
                  </p>
                </div>
              </Carousel.Caption>
            </Carousel.Item>
          ))}
        </Carousel>
      </main>

      {/* About Section */}
      <section id="about" className="about-section">
        <Container>
          <h2 className="mb-4 text-white animate-about-title">About Online Yoga</h2>
          <p className="about-text animate-about-text">
            YogaStream is a comprehensive online platform that connects individuals with certified yoga instructors to provide guided sessions that can be accessed anytime, anywhere. Whether you're a beginner taking your first steps into yoga or an advanced practitioner seeking to deepen your practice, YogaStream offers tailored programs to suit every level.
          </p>
        </Container>
      </section>

      {/* Footer Section */}
<footer className="footer-section">
  <Container className="text-center">
    <div className="footer-row">
      {/* Left Part: Links */}
      <div className="footer-column">
        <h5 className="footer-heading">Quick Links</h5>
        <a href="#home" className="footer-link">Home</a>
        <a href="#about" className="footer-link">About Us</a>
        <a href="/login" className="footer-link">Sign In</a>
      </div>

      <div className="footer-divider"></div>

      {/* Right Part: Contact Info */}
      <div className="footer-column">
        <h5 className="footer-heading">Contact Us</h5>
        <p className="footer-text">
          📧 <a href="mailto:anjithaanji103@gmail.com">anjithaanji103@gmail.com</a><br />
          📞 <a href="tel:+917306739589">7306739589</a><br />
          📍 Kochi, Kerala, India
        </p>
      </div>
    </div>

    <div className="footer-credit mt-3">
      © {new Date().getFullYear()} YogaStream. All rights reserved.
    </div>
  </Container>
</footer>

      
    </div>
  );
};

export default Homepage;
