import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate, Link } from 'react-router-dom';

export default function Loginpage() {
  const [record, setRecord] = useState({ email: "", password: "" });
  const navigate = useNavigate();

  const handleChange = (e) => {
    setRecord({ ...record, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!record.email || !record.password) {
      alert("Please enter both email and password");
      return;
    }

    if (record.email === 'admin@gmail.com' && record.password === 'admin123') {
      alert('Admin login successful');
      localStorage.setItem('role', 'admin');
      navigate('/adminhome');
      return;
    }

    axios.post("http://localhost:9001/api/user/loginuser", record)
      .then((res) => {
        alert(res.data.msg);
        if (res.status === 200) {
          localStorage.setItem("token", res.data.token);
          localStorage.setItem("role", res.data.user?.role || "");
          localStorage.setItem("userId", res.data.user?.id || res.data.user?._id || "");
          if (res.data.user?.role?.toLowerCase() === 'instructor') {
            localStorage.setItem("instructorId", res.data.user._id);
          }
          const role = res.data.user?.role?.toLowerCase() || 'user';
          if (role === 'instructor') navigate("/instructorhome");
          else navigate("/userhome");
        }
      })
      .catch((err) => {
        console.error("Login error:", err.response?.data || err.message);
        alert("User Login failed: " + (err.response?.data?.msg || "Unknown error"));
      });
  };

  return (
    <div className="login-wrapper">
      <form className="form" onSubmit={handleSubmit}>
        
        {/* Email Field */}
        <div className="input-group">
          <input
            type="email"
            name="email"
            className="input"
            value={record.email}
            onChange={handleChange}
            required
          />
          <label className="user-label">Email</label>
        </div>

        {/* Password Field */}
        <div className="input-group">
          <input
            type="password"
            name="password"
            className="input"
            value={record.password}
            onChange={handleChange}
            required
          />
          <label className="user-label">Password</label>
        </div>

        {/* Options */}
        <div className="flex-row">
          <div>
            <input type="checkbox" id="remember" />
            <label htmlFor="remember">Remember me</label>
          </div>
          <span className="span">Forgot password?</span>
        </div>

        {/* Sign In Button */}
        <button type="submit" className="cssbuttons-io">
          <span>Sign In</span>
        </button>

        {/* Links */}
        <p className="p">
          Don't have an account?
          <Link className="span" to="/register"> Sign Up</Link>
        </p>

        <p className="p">
          <Link className="span" to="/">← Back to Home</Link>
        </p>
      </form>
    </div>
  );
}
